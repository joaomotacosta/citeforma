num1 = 52
num2 = 106

print(num1*num2)
print(num1/num2)