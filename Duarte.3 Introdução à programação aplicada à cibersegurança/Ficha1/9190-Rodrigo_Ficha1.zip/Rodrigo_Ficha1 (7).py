num1 = 100
num2 = 89

if num1 > num2:
    print("a > O primeiro número é superior.")
else:
    print("a > O segundo número é superior.")

if num1 == num2:
    print("b > O primeiro número é igual ao segundo número.")
else:
    print("b > O primeiro número não é igual ao segundo número.")

if num1 != num2:
    print("c > O primeiro número é diferente do segundo número.")
else:
    print("c > O primeiro número não é diferente do segundo número.")

if num1 <= 100:
    print("d > O primeiro número é menor ou igual a 100.")
else:
    print("d > O primeiro número é maior que 100.")

if num1 <= 100:
    print("e > O primeiro número é menor ou igual a 100.")
else:
    print("e > O primeiro número é maior que 100.")

if num2 <= 100:
    print("e > O segundo número é menor ou igual a 100.")
else:
    print("e > O segundo número é maior do que 100.")

if num1 >= 100:
    print("f > O primeiro número é maior ou igual a 100.")
else:
    print("f > O primeiro número é menor que 100.")

if num2 >= 100:
    print("f > O segundo número é maior ou igual a 100.")
else:
    print("f > O segundo número é menor do que 100.")