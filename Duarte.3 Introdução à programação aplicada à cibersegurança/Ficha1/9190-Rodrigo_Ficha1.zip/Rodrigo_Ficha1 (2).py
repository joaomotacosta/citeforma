num1 = 52
num2 = 106

sum = num1+num2
print(sum)