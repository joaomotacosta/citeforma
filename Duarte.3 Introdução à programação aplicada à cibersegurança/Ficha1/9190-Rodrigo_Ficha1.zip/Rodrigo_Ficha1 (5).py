num1 = 4

print(num1**3)